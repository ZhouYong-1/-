#include "usart.h"
#include "led.h"
#include <MATH.H>
#include "24cxx.h" 
#include "CS5463.h"

//SDI D1 //
//GND //
//CS D4 //
//RST D5//
//SCLK D0//
//5V //
//3V3 //

u8 WorkState=0;//����״̬�����ģʽ��ѧϰģʽ //

u32 V_RMS,I_RMS,PF,PactiveRMS,Qavg;//��ѹ��Чֵ��������Чֵ���������أ��й����ʣ��޹����� //


int linshi;
char BlueBoothdisplayVrms[4]={0};
char BlueBoothdisplayIrms[6]={0};
char BlueBoothdisplayPF[6]={0};
char BlueBoothdisplayyougong[5]={0};
char BlueBoothdisplaywugong[5]={0};
	


int p;
unsigned char v;
void BlueBooth(void);
void HmiDisPlay(void);


int main(void)
{ 

	
	float min;
	int i=0;
	float juli[32];
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//����ϵͳ�ж����ȼ�����2
	delay_init(168);		//��ʱ��ʼ�� 
	uart_init(9600);	//���ڳ�ʼ��������Ϊ9600
	LED_Init();	
  delay_ms(1200); 	//��ʼ����LED���ӵ�Ӳ���ӿ�  
  AT24CXX_Init();
	CS5463_Init();

		while(1)
		{
	  sta	= CS5463_GetStatusReg();		  	//����жϲ�����ԭ��
		if(0x01==( sta&0x01))		   			//��ȡ������ѹ
	{	
			CS5463_ResetStatusReg();			//�����־
			V_RMS=CS5463_GetVoltRMS();				//��ȡ��ѹ
			I_RMS=CS5463_GetCurrentRMS();				//��ȡ����
	    PF=CS5463_GetPowerFactor();			//��ȡ��������
      PactiveRMS=CS54363_GetPactiveRMS();   //��ȡ�й�����
			Qavg=CS54363_GetQavg();//��ȡ�޹�����
			if(V_RMS>220)
			{
				for(i=0;i<=31;i++)  //ŷʽ����ʶ���㷨  //
				{
					juli[i]=(PactiveRMS-xuexishuju[i][0])* (PactiveRMS-xuexishuju[i][0])*0.4+(Qavg-xuexishuju[i][1])* (Qavg-xuexishuju[i][1])*0.6;			
				}
				i=1;
				p=0;
				min=juli[0];
				for(i=1;i<=31;i++)
				{
				if(juli[i]<min) {min=juli[i];p=i;}
				}
			}
	  
	     	v=State[p];
			
			  MonitorIrms[9]=(I_RMS%10000)/1000+0x30;
				MonitorIrms[10]=(I_RMS%1000)/100+0x30;
				MonitorIrms[11]=(I_RMS%100)/10+0x30;
				MonitorIrms[12]=I_RMS%10+0x30;
			
				
				BlueBoothdisplayVrms[0]=(V_RMS%1000)/100+0x30;
				BlueBoothdisplayVrms[1]=(V_RMS%100)/10+0x30;
				BlueBoothdisplayVrms[2]=V_RMS%10+0x30;
			  BlueBoothdisplayVrms[3]='v';
			  
			for(i=0;i<=3;i++)
				{
						USART_SendData(USART1, BlueBoothdisplayVrms[i]); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){};//�ȴ����ͽ���	
				}
		
			USART_SendData(USART1, ' '); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){};
			USART_SendData(USART1, ' '); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){};
					
			
				Monitoryougong[9]=(PactiveRMS%10000)/1000+0x30;
				Monitoryougong[10]=(PactiveRMS%1000)/100+0x30;
				Monitoryougong[11]=(PactiveRMS%100)/10+0x30;
				Monitoryougong[12]=PactiveRMS%10+0x30;				
				
				
			  BlueBoothdisplayIrms[0]=(I_RMS%10000)/1000+0x30;
				BlueBoothdisplayIrms[1]=(I_RMS%1000)/100+0x30;
				BlueBoothdisplayIrms[2]=(I_RMS%100)/10+0x30;
				BlueBoothdisplayIrms[3]=I_RMS%10+0x30;
				BlueBoothdisplayIrms[4]='m';
				BlueBoothdisplayIrms[5]='A';
				
				for(i=0;i<=5;i++)
				{
						USART_SendData(USART1,  BlueBoothdisplayIrms[i]); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){};//�ȴ����ͽ���	
				}
				
					USART_SendData(USART1, ' '); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){};
			    USART_SendData(USART1, ' '); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){};
				
				Monitorwugong[9]=(Qavg%10000)/1000+0x30;
				Monitorwugong[10]=(Qavg%1000)/100+0x30;
				Monitorwugong[11]=(Qavg%100)/10+0x30;
				Monitorwugong[12]=Qavg%10+0x30;		
				
				
				
				
				BlueBoothdisplayyougong[0]=(PactiveRMS%10000)/1000+0x30;
				BlueBoothdisplayyougong[1]=(PactiveRMS%1000)/100+0x30;
				BlueBoothdisplayyougong[2]=(PactiveRMS%100)/10+0x30;
				BlueBoothdisplayyougong[3]=PactiveRMS%10+0x30;
				BlueBoothdisplayyougong[4]='w';
						
						for(i=0;i<=4;i++)
				{
						USART_SendData(USART1, BlueBoothdisplayyougong[i]); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){};//�ȴ����ͽ���	
				}
				
					USART_SendData(USART1, ' '); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){};
			    USART_SendData(USART1, ' '); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){};
						
				BlueBoothdisplaywugong[0]=(Qavg%10000)/1000+0x30;
				BlueBoothdisplaywugong[1]=(Qavg%1000)/100+0x30;
				BlueBoothdisplaywugong[2]=(Qavg%100)/10+0x30;
				BlueBoothdisplaywugong[3]=Qavg%10+0x30;
				BlueBoothdisplaywugong[4]='w';
				
						for(i=0;i<=4;i++)
				{
						USART_SendData(USART1, BlueBoothdisplaywugong[i]); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){};//�ȴ����ͽ���	
				}
				
					USART_SendData(USART1, ' '); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){};
			    USART_SendData(USART1, ' '); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){};
			
				MonitorPF[9]=( PF%10000)/1000+0x30;
				MonitorPF[10]=( PF%1000)/100+0x30;
				MonitorPF[11]='.';
        MonitorPF[12]=( PF%100)/10+0x30;		
				MonitorPF[13]=PF%10+0x30;

        BlueBoothdisplayPF[0]=  ( PF%10000)/1000+0x30;
				BlueBoothdisplayPF[1]=( PF%1000)/100+0x30;
				BlueBoothdisplayPF[2]= '.';  
				BlueBoothdisplayPF[3]=( PF%100)/10+0x30;	
				BlueBoothdisplayPF[4]=PF%10+0x30;
				BlueBoothdisplayPF[5]='%';
				
						
						for(i=0;i<=5;i++)
				{
						USART_SendData(USART1, BlueBoothdisplayPF[i]); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){};//�ȴ����ͽ���	
				}
				
					USART_SendData(USART1, ' '); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){};
			    USART_SendData(USART1, ' '); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){};
				  USART_SendData(USART1, 0x0d); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){};
			    USART_SendData(USART1,0x0a); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){};
			
			if(WorkState==1) // ���ģʽ//
				{
for( i=0;i<=4;i++)
			{	
				if(((v>>i)&0x01)==1)
				{
					
							 MonitorState[1]='1';
							if(i==0){MonitorState[2]='6';USART_SendData(USART1, 'i'); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){}
							                             USART_SendData(USART1, 'r'); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){}
                                           USART_SendData(USART1, 'o'); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){}
                                           USART_SendData(USART1, 'n'); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){}
                                          
																					 USART_SendData(USART1, ' '); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){}
							        }
							if(i==1){MonitorState[2]='7';USART_SendData(USART1, 'i'); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){}
                                           USART_SendData(USART1, 'p'); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){}
                                           USART_SendData(USART1, 'a'); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){}
                                           USART_SendData(USART1, 'd'); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){} 
							                             USART_SendData(USART1, ' '); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){}
											}
							
							
					 
							if(i==2){MonitorState[2]='8';USART_SendData(USART1, 'f'); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){}
                                           USART_SendData(USART1, 'a'); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){}
                                           USART_SendData(USART1, 'n'); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){}                                      
							                             USART_SendData(USART1, ' '); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){}
											}
							if(i==3){MonitorState[2]='9';USART_SendData(USART1, 'b'); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){}
                                           USART_SendData(USART1, 'u'); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){}
                                           USART_SendData(USART1, 'l'); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){}
                                           USART_SendData(USART1, 'b'); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){} 
							                             USART_SendData(USART1, ' '); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){}
											}
							if(i==4){ MonitorState[1]='2';MonitorState[2]='0';USART_SendData(USART1, 'h'); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){}
                                           USART_SendData(USART1, 'e'); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){}
                                           USART_SendData(USART1, 'a'); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){}
                                           USART_SendData(USART1, 't'); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){} 
							                             USART_SendData(USART1, 'e'); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){}
																					 USART_SendData(USART1, 'r'); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){}
																					 USART_SendData(USART1, ' '); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){}
																					 USART_SendData(USART1, 0x0d); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){};
			                                     USART_SendData(USART1,0x0a); while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET){};
											}
							MonitorState[9]=0xBF;
							MonitorState[10]=0xAA;
							
							
					       for(linshi=0;linshi<=14;linshi++)
				      {
						    USART_SendData(USART2, MonitorState[linshi]); while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET){};//�ȴ����ͽ���	
				       }
			       
						
			}
				else 
				{
					{
							   MonitorState[1]='1'; 
							if(i==0)MonitorState[2]='6';
							if(i==1)MonitorState[2]='7';
							if(i==2)MonitorState[2]='8';
							if(i==3)MonitorState[2]='9';
						  if(i==4){  MonitorState[1]='2';MonitorState[2]='0';}
							MonitorState[9]=0xB9;
							MonitorState[10]=0xD8;
								
					       for(linshi=0;linshi<=14;linshi++)
				      {
						    USART_SendData(USART2, MonitorState[linshi]); while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET){};//�ȴ����ͽ���	
				       }
			       }
					
				}
			
			}
	
			
			
				
				
				
				for(linshi=0;linshi<=18;linshi++)
				{
						USART_SendData(USART2,MonitorIrms[linshi]); while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET){};//�ȴ����ͽ���	
				}
					for(linshi=0;linshi<=18;linshi++)
				{
						USART_SendData(USART2, MonitorPF[linshi]); while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET){};//�ȴ����ͽ���	
				}
					for(linshi=0;linshi<=17;linshi++)
				{
						USART_SendData(USART2, Monitoryougong[linshi]); while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET){};//�ȴ����ͽ���	
				}
					for(linshi=0;linshi<=17;linshi++)
				{
						USART_SendData(USART2, Monitorwugong[linshi]); while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET){};//�ȴ����ͽ���	
				}
				
				
			}
				if(WorkState ==2)   //ѧϰģʽ //
					{
					 Monitoryougong[2]=0x35;
				   Monitorwugong[2]=0x36;
					for(linshi=0;linshi<=17;linshi++)
				{
						USART_SendData(USART2, Monitoryougong[linshi]); while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET){};//�ȴ����ͽ���	
				}
					for(linshi=0;linshi<=17;linshi++)
				{
						USART_SendData(USART2, Monitorwugong[linshi]); while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET){};//�ȴ����ͽ���	
				}
				 Monitoryougong[2]=0x33;
				 Monitorwugong[2]=0x34;}
			}
		}
	}

	
	
	
	
	

	